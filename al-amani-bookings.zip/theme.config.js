/** @type {const} */
const themeColors = {
  primary: { light: '#8B5CF6', dark: '#A78BFA' },
  background: { light: '#FBF8F4', dark: '#171326' },
  surface: { light: '#FFFFFF', dark: '#241D38' },
  foreground: { light: '#231942', dark: '#F7F2FF' },
  muted: { light: '#776B8A', dark: '#B8ADC9' },
  border: { light: '#EEE9F3', dark: '#3A3152' },
  success: { light: '#178F5B', dark: '#6EE7B7' },
  warning: { light: '#D89B21', dark: '#F6C85F' },
  error: { light: '#C94C4C', dark: '#F28B8B' },
};

module.exports = { themeColors };
