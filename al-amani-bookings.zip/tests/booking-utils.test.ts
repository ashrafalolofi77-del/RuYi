import { describe, expect, it } from "vitest";

import { monthKey, paymentPercent, remainingAmount, statusForPayment } from "../shared/booking-utils";

describe("booking financial helpers", () => {
  it("calculates remaining amount without going below zero", () => {
    expect(remainingAmount(8500, 3000)).toBe(5500);
    expect(remainingAmount(4000, 4500)).toBe(0);
  });

  it("derives confirmation status from payment", () => {
    expect(statusForPayment(5200, 5200)).toBe("مؤكد");
    expect(statusForPayment(5200, 2000)).toBe("معلّق");
    expect(statusForPayment(0, 0)).toBe("معلّق");
  });

  it("clamps payment progress to a safe percentage", () => {
    expect(paymentPercent(10000, 2500)).toBe(25);
    expect(paymentPercent(10000, 12000)).toBe(100);
    expect(paymentPercent(0, 100)).toBe(0);
  });

  it("formats month keys consistently", () => {
    expect(monthKey(2026, 9)).toBe("2026-09");
    expect(monthKey(2026, 12)).toBe("2026-12");
  });
});
