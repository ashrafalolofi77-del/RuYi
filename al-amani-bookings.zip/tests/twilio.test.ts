import { describe, expect, it } from "vitest";

import { buildBookingConfirmationMessage } from "../server/twilio";

describe("Twilio booking confirmation", () => {
  it("builds a clear Arabic confirmation message", () => {
    const message = buildBookingConfirmationMessage({
      to: "+966500000001",
      eventName: "زفاف عائلة الشمري",
      date: "2026-09-18",
      time: "08:30 م",
      location: "قاعة ليالي نجد",
    });

    expect(message).toContain("زفاف عائلة الشمري");
    expect(message).toContain("2026-09-18");
    expect(message).toContain("قاعة ليالي نجد");
    expect(message.length).toBeLessThan(320);
  });
});
