import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { sendBookingConfirmation } from "./twilio";
import { z } from "zod";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  sms: router({
    sendBookingConfirmation: protectedProcedure
      .input(z.object({
        to: z.string().regex(/^\+[1-9]\d{7,14}$/, "Use E.164 phone format, for example +9665XXXXXXXX."),
        eventName: z.string().trim().min(1).max(120),
        date: z.string().trim().min(1).max(30),
        time: z.string().trim().min(1).max(30),
        location: z.string().trim().min(1).max(160),
      }))
      .mutation(async ({ input }) => {
        const result = await sendBookingConfirmation(input);
        return { success: true as const, ...result };
      }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
