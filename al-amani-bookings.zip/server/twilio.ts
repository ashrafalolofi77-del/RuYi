import { ENV } from "./_core/env";

export type BookingConfirmationInput = {
  to: string;
  eventName: string;
  date: string;
  time: string;
  location: string;
};

export function buildBookingConfirmationMessage(input: BookingConfirmationInput) {
  return `فرقة الأماني: تم تأكيد حجزكم «${input.eventName}» بتاريخ ${input.date} الساعة ${input.time} في ${input.location}. شكرًا لثقتكم بنا.`;
}

export async function sendBookingConfirmation(input: BookingConfirmationInput) {
  if (!ENV.twilioAccountSid || !ENV.twilioAuthToken) {
    throw new Error("Twilio is not configured. Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN.");
  }
  if (!ENV.twilioMessagingServiceSid && !ENV.twilioFromNumber) {
    throw new Error("Set TWILIO_MESSAGING_SERVICE_SID or TWILIO_FROM_NUMBER.");
  }

  const body = buildBookingConfirmationMessage(input);
  const params = new URLSearchParams({ To: input.to, Body: body });
  if (ENV.twilioMessagingServiceSid) {
    params.set("MessagingServiceSid", ENV.twilioMessagingServiceSid);
  } else if (ENV.twilioFromNumber) {
    params.set("From", ENV.twilioFromNumber);
  }

  const credentials = Buffer.from(`${ENV.twilioAccountSid}:${ENV.twilioAuthToken}`).toString("base64");
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${ENV.twilioAccountSid}/Messages.json`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: params.toString(),
  });

  const result = (await response.json()) as { sid?: string; status?: string; message?: string; code?: number };
  if (!response.ok) {
    throw new Error(result.message || `Twilio request failed (${response.status}).`);
  }

  return { sid: result.sid ?? null, status: result.status ?? "queued" };
}
