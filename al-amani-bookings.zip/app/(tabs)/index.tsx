import AsyncStorage from "@react-native-async-storage/async-storage";
import { MaterialIcons } from "@expo/vector-icons";
import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { paymentPercent, remainingAmount, statusForPayment } from "@/shared/booking-utils";
import { trpc } from "@/lib/trpc";

const STORAGE_KEY = "al-amani-bookings-v1";

type Status = "مؤكد" | "معلّق" | "مكتمل";
type Booking = {
  id: string;
  eventName: string;
  client: string;
  phone: string;
  date: string;
  time: string;
  location: string;
  type: string;
  total: number;
  paid: number;
  status: Status;
  guests: string;
  notes: string;
};

type Section = "home" | "bookings" | "calendar" | "finance";

const today = new Date();
const pad = (value: number) => String(value).padStart(2, "0");
const dateKey = (date: Date) => `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
const money = (value: number) => `${value.toLocaleString("ar-SA")} ر.س`;

const seedBookings: Booking[] = [
  {
    id: "demo-1",
    eventName: "زفاف عائلة الشمري",
    client: "محمد الشمري",
    phone: "+966500000001",
    date: "2026-09-18",
    time: "08:30 م",
    location: "قاعة ليالي نجد",
    type: "زفاف",
    total: 8500,
    paid: 3000,
    status: "مؤكد",
    guests: "400",
    notes: "فرقة كاملة مع العود والإيقاعات الشعبية",
  },
  {
    id: "demo-2",
    eventName: "ليلة الأصدقاء",
    client: "سارة العتيبي",
    phone: "+966500000002",
    date: "2026-09-24",
    time: "09:00 م",
    location: "استراحة النخيل",
    type: "حفلة خاصة",
    total: 5200,
    paid: 5200,
    status: "مؤكد",
    guests: "120",
    notes: "قائمة أغاني خفيفة وافتتاحية خاصة",
  },
  {
    id: "demo-3",
    eventName: "زفاف خالد ونورة",
    client: "خالد المطيري",
    phone: "+966500000003",
    date: "2026-10-03",
    time: "08:00 م",
    location: "فندق السحاب",
    type: "زفاف",
    total: 9800,
    paid: 2000,
    status: "معلّق",
    guests: "600",
    notes: "بانتظار تأكيد وقت الدخول ومواقف الفرقة",
  },
  {
    id: "demo-4",
    eventName: "احتفال التخرج",
    client: "نادي الإبداع",
    phone: "+966500000004",
    date: "2026-09-06",
    time: "07:00 م",
    location: "مركز المؤتمرات",
    type: "فعالية",
    total: 4300,
    paid: 4300,
    status: "مكتمل",
    guests: "250",
    notes: "تم التسليم بنجاح",
  },
];

const emptyForm = {
  eventName: "",
  client: "",
  phone: "",
  date: dateKey(new Date(today.getFullYear(), today.getMonth(), today.getDate() + 7)),
  time: "08:00 م",
  location: "",
  type: "زفاف",
  total: "",
  paid: "",
  guests: "",
  notes: "",
};

function getMonthLabel(date: Date) {
  return new Intl.DateTimeFormat("ar-SA", { month: "long", year: "numeric" }).format(date);
}

function getCalendarDays(month: Date) {
  const first = new Date(month.getFullYear(), month.getMonth(), 1);
  const startOffset = (first.getDay() + 1) % 7;
  const lastDay = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const previousLast = new Date(month.getFullYear(), month.getMonth(), 0).getDate();
  const days: { key: string; day: number; current: boolean }[] = [];
  for (let i = startOffset - 1; i >= 0; i -= 1) {
    const date = new Date(month.getFullYear(), month.getMonth() - 1, previousLast - i);
    days.push({ key: dateKey(date), day: date.getDate(), current: false });
  }
  for (let day = 1; day <= lastDay; day += 1) {
    const date = new Date(month.getFullYear(), month.getMonth(), day);
    days.push({ key: dateKey(date), day, current: true });
  }
  while (days.length < 42) {
    const index = days.length - (startOffset + lastDay) + 1;
    const date = new Date(month.getFullYear(), month.getMonth() + 1, index);
    days.push({ key: dateKey(date), day: date.getDate(), current: false });
  }
  return days;
}

export default function HomeScreen() {
  const [section, setSection] = useState<Section>("home");
  const [bookings, setBookings] = useState<Booking[]>(seedBookings);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [selectedDate, setSelectedDate] = useState(dateKey(today));
  const [calendarMonth, setCalendarMonth] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"الكل" | Status>("الكل");
  const smsMutation = trpc.sms.sendBookingConfirmation.useMutation();

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((stored) => {
      if (stored) {
        try {
          setBookings(JSON.parse(stored));
        } catch {
          setBookings(seedBookings);
        }
      }
    });
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
  }, [bookings]);

  const upcoming = useMemo(
    () => bookings.filter((booking) => booking.date >= dateKey(today) && booking.status !== "مكتمل").sort((a, b) => a.date.localeCompare(b.date)),
    [bookings],
  );
  const confirmed = bookings.filter((booking) => booking.status === "مؤكد").length;
  const pending = bookings.filter((booking) => booking.status === "معلّق").length;
  const totalDue = bookings.reduce((sum, booking) => sum + remainingAmount(booking.total, booking.paid), 0);
  const monthBookings = bookings.filter((booking) => booking.date.startsWith(`${calendarMonth.getFullYear()}-${pad(calendarMonth.getMonth() + 1)}`));
  const filteredBookings = bookings.filter((booking) => {
    const matchesFilter = filter === "الكل" || booking.status === filter;
    const haystack = `${booking.eventName} ${booking.client} ${booking.location}`.toLowerCase();
    return matchesFilter && haystack.includes(query.toLowerCase());
  });
  const selectedBookings = bookings.filter((booking) => booking.date === selectedDate);

  const saveBooking = () => {
    if (!form.eventName.trim() || !form.client.trim() || !form.date.trim() || !form.total.trim()) {
      Alert.alert("بيانات ناقصة", "أدخل اسم المناسبة واسم العميل والتاريخ والمبلغ الإجمالي.");
      return;
    }
    const total = Number(form.total.replace(/[^0-9.]/g, "")) || 0;
    const paid = Number(form.paid.replace(/[^0-9.]/g, "")) || 0;
    const newBooking: Booking = {
      id: `booking-${Date.now()}`,
      eventName: form.eventName.trim(),
      client: form.client.trim(),
      phone: form.phone.trim(),
      date: form.date.trim(),
      time: form.time.trim() || "08:00 م",
      location: form.location.trim() || "لم يحدد بعد",
      type: form.type.trim() || "مناسبة",
      total,
      paid: Math.min(paid, total),
      status: statusForPayment(total, paid),
      guests: form.guests.trim() || "غير محدد",
      notes: form.notes.trim(),
    };
    setBookings((current) => [newBooking, ...current]);
    setSelectedDate(newBooking.date);
    setForm(emptyForm);
    setShowForm(false);
    setSection("bookings");
  };

  const deleteBooking = (booking: Booking) => {
    Alert.alert("حذف الحجز", `هل تريد حذف «${booking.eventName}»؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => setBookings((current) => current.filter((item) => item.id !== booking.id)) },
    ]);
  };

  const sendConfirmationSms = async (booking: Booking) => {
    if (!booking.phone) {
      Alert.alert("رقم الهاتف غير موجود", "أضف رقم العميل بصيغة دولية مثل +9665XXXXXXXX قبل الإرسال.");
      return;
    }
    try {
      const result = await smsMutation.mutateAsync({
        to: booking.phone,
        eventName: booking.eventName,
        date: booking.date,
        time: booking.time,
        location: booking.location,
      });
      Alert.alert("تم إرسال التأكيد", `حالة الرسالة: ${result.status}`);
    } catch (error) {
      Alert.alert("تعذر إرسال الرسالة", error instanceof Error ? error.message : "تحقق من تسجيل الدخول وإعدادات Twilio.");
    }
  };

  const renderBookingCard = ({ item }: { item: Booking }) => (
    <View style={styles.bookingCard}>
      <View style={styles.bookingTopRow}>
        <View style={[styles.typeBadge, item.status === "مكتمل" ? styles.greenBadge : item.status === "معلّق" ? styles.amberBadge : styles.purpleBadge]}>
          <Text style={styles.typeBadgeText}>{item.status}</Text>
        </View>
        <View style={styles.bookingTitleWrap}>
          <Text style={styles.bookingTitle} numberOfLines={1}>{item.eventName}</Text>
          <Text style={styles.bookingClient}>{item.client} · {item.type}</Text>
        </View>
        <View style={styles.dateBox}>
          <Text style={styles.dateBoxDay}>{item.date.slice(-2)}</Text>
          <Text style={styles.dateBoxMonth}>{new Intl.DateTimeFormat("ar-SA", { month: "short" }).format(new Date(`${item.date}T12:00:00`))}</Text>
        </View>
      </View>
      <View style={styles.bookingMetaRow}>
        <View style={styles.metaItem}><MaterialIcons name="schedule" size={16} color="#8B5CF6" /><Text style={styles.metaText}>{item.time}</Text></View>
        <View style={styles.metaItem}><MaterialIcons name="location-on" size={16} color="#8B5CF6" /><Text style={styles.metaText} numberOfLines={1}>{item.location}</Text></View>
      </View>
      <View style={styles.paymentRow}>
        <View><Text style={styles.paymentLabel}>المتبقي</Text><Text style={styles.paymentValue}>{money(remainingAmount(item.total, item.paid))}</Text></View>
        <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${paymentPercent(item.total, item.paid)}%` }]} /></View>
        <Text style={styles.paymentPercent}>{paymentPercent(item.total, item.paid)}%</Text>
      </View>
      <View style={styles.cardActions}>
        <Text style={styles.totalText}>الإجمالي {money(item.total)}</Text>
        <View style={styles.cardActionGroup}><Pressable disabled={smsMutation.isPending} onPress={() => sendConfirmationSms(item)} style={({ pressed }) => [styles.smsButton, pressed && styles.pressed, smsMutation.isPending && styles.disabledButton]}><MaterialIcons name="sms" size={17} color="#178F5B" /><Text style={styles.smsText}>{smsMutation.isPending ? "جاري الإرسال" : "تأكيد SMS"}</Text></Pressable><Pressable onPress={() => deleteBooking(item)} style={({ pressed }) => [styles.deleteButton, pressed && styles.pressed]}><MaterialIcons name="delete-outline" size={18} color="#C94C4C" /><Text style={styles.deleteText}>حذف</Text></Pressable></View>
      </View>
    </View>
  );

  const renderHome = () => (
    <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={styles.heroRow}>
        <View style={styles.avatar}><Text style={styles.avatarText}>أ</Text></View>
        <View style={styles.heroText}><Text style={styles.greeting}>مساء الخير، فريق الأماني</Text><Text style={styles.heroSubtitle}>جاهزون لصناعة ليلة لا تُنسى؟</Text></View>
        <Pressable style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}><MaterialIcons name="notifications-none" size={23} color="#231942" /></Pressable>
      </View>
      <View style={styles.brandBanner}>
        <View style={styles.brandIcon}><MaterialIcons name="music-note" size={28} color="#FFFFFF" /></View>
        <View style={styles.brandCopy}><Text style={styles.brandTitle}>فرقة الأماني الموسيقية</Text><Text style={styles.brandCaption}>لوحة التحكم بالحجوزات والمناسبات</Text></View>
        <View style={styles.liveDot}><View style={styles.dot} /><Text style={styles.liveText}>نشطة</Text></View>
      </View>
      <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>لمحة سريعة</Text><Text style={styles.sectionHint}>هذا الشهر</Text></View>
      <View style={styles.statsGrid}>
        <View style={[styles.statCard, styles.statCardPurple]}><View style={styles.statIcon}><MaterialIcons name="event-available" size={20} color="#8B5CF6" /></View><Text style={styles.statNumber}>{monthBookings.length}</Text><Text style={styles.statLabel}>مناسبة مجدولة</Text></View>
        <View style={[styles.statCard, styles.statCardGreen]}><View style={styles.statIcon}><MaterialIcons name="check-circle-outline" size={20} color="#178F5B" /></View><Text style={styles.statNumber}>{confirmed}</Text><Text style={styles.statLabel}>حجز مؤكد</Text></View>
        <View style={[styles.statCard, styles.statCardAmber]}><View style={styles.statIcon}><MaterialIcons name="hourglass-empty" size={20} color="#D89B21" /></View><Text style={styles.statNumber}>{pending}</Text><Text style={styles.statLabel}>بانتظار التأكيد</Text></View>
        <View style={[styles.statCard, styles.statCardRose]}><View style={styles.statIcon}><MaterialIcons name="account-balance-wallet" size={20} color="#C94C4C" /></View><Text style={styles.statNumber}>{(totalDue / 1000).toFixed(1)}k</Text><Text style={styles.statLabel}>مستحقات (ر.س)</Text></View>
      </View>
      <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>الإجراءات السريعة</Text></View>
      <View style={styles.quickActions}>
        <Pressable onPress={() => { setForm(emptyForm); setShowForm(true); }} style={({ pressed }) => [styles.primaryAction, pressed && styles.pressed]}><MaterialIcons name="add" size={22} color="#FFFFFF" /><Text style={styles.primaryActionText}>حجز جديد</Text></Pressable>
        <Pressable onPress={() => setSection("calendar")} style={({ pressed }) => [styles.secondaryAction, pressed && styles.pressed]}><MaterialIcons name="calendar-month" size={21} color="#8B5CF6" /><Text style={styles.secondaryActionText}>عرض التقويم</Text></Pressable>
      </View>
      <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>أقرب المناسبات</Text><Pressable onPress={() => setSection("bookings")}><Text style={styles.linkText}>عرض الكل</Text></Pressable></View>
      {upcoming.slice(0, 3).map((item) => <Pressable key={item.id} onPress={() => { setSelectedDate(item.date); setSection("calendar"); }} style={({ pressed }) => [styles.upcomingCard, pressed && styles.pressed]}><View style={styles.upcomingDate}><Text style={styles.upcomingDay}>{item.date.slice(-2)}</Text><Text style={styles.upcomingMonth}>{new Intl.DateTimeFormat("ar-SA", { month: "short" }).format(new Date(`${item.date}T12:00:00`))}</Text></View><View style={styles.upcomingInfo}><Text style={styles.upcomingTitle} numberOfLines={1}>{item.eventName}</Text><Text style={styles.upcomingMeta}>{item.time} · {item.location}</Text></View><MaterialIcons name="chevron-left" size={23} color="#A6A0B4" /></Pressable>)}
      {upcoming.length === 0 && <View style={styles.emptyState}><MaterialIcons name="event-busy" size={34} color="#A6A0B4" /><Text style={styles.emptyTitle}>لا توجد مناسبات قادمة</Text></View>}
    </ScrollView>
  );

  const renderBookings = () => (
    <View style={styles.flexOne}>
      <View style={styles.pageHeader}><View><Text style={styles.pageEyebrow}>إدارة المواعيد</Text><Text style={styles.pageTitle}>كل الحجوزات</Text></View><Pressable onPress={() => { setForm(emptyForm); setShowForm(true); }} style={({ pressed }) => [styles.roundPrimary, pressed && styles.pressed]}><MaterialIcons name="add" size={25} color="#FFFFFF" /></Pressable></View>
      <View style={styles.searchBox}><MaterialIcons name="search" size={21} color="#A6A0B4" /><TextInput value={query} onChangeText={setQuery} placeholder="ابحث باسم المناسبة أو العميل" placeholderTextColor="#A6A0B4" style={styles.searchInput} /></View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>{(["الكل", "مؤكد", "معلّق", "مكتمل"] as const).map((option) => <Pressable key={option} onPress={() => setFilter(option)} style={[styles.filterChip, filter === option && styles.activeFilterChip]}><Text style={[styles.filterText, filter === option && styles.activeFilterText]}>{option}</Text></Pressable>)}</ScrollView>
      <FlatList data={filteredBookings} keyExtractor={(item) => item.id} renderItem={renderBookingCard} contentContainerStyle={styles.listContent} showsVerticalScrollIndicator={false} ListEmptyComponent={<View style={styles.emptyState}><MaterialIcons name="search-off" size={34} color="#A6A0B4" /><Text style={styles.emptyTitle}>لم نعثر على حجوزات</Text><Text style={styles.emptySubtitle}>جرّب تعديل البحث أو أضف حجزًا جديدًا</Text></View>} />
    </View>
  );

  const renderCalendar = () => {
    const days = getCalendarDays(calendarMonth);
    const weekdayLabels = ["أحد", "اثن", "ثلا", "أرب", "خمي", "جمع", "سبت"];
    return <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={styles.pageHeader}><View><Text style={styles.pageEyebrow}>نظرة زمنية</Text><Text style={styles.pageTitle}>تقويم المناسبات</Text></View><Pressable onPress={() => { setCalendarMonth(new Date(today.getFullYear(), today.getMonth(), 1)); setSelectedDate(dateKey(today)); }} style={styles.todayButton}><Text style={styles.todayButtonText}>اليوم</Text></Pressable></View>
      <View style={styles.calendarCard}><View style={styles.monthHeader}><Pressable onPress={() => setCalendarMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 1))} style={styles.monthArrow}><MaterialIcons name="chevron-right" size={24} color="#231942" /></Pressable><Text style={styles.monthTitle}>{getMonthLabel(calendarMonth)}</Text><Pressable onPress={() => setCalendarMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() - 1, 1))} style={styles.monthArrow}><MaterialIcons name="chevron-left" size={24} color="#231942" /></Pressable></View><View style={styles.weekRow}>{weekdayLabels.map((day) => <Text key={day} style={styles.weekLabel}>{day}</Text>)}</View><View style={styles.calendarGrid}>{days.map((day) => { const count = bookings.filter((booking) => booking.date === day.key).length; const active = day.key === selectedDate; return <Pressable key={day.key} onPress={() => setSelectedDate(day.key)} style={[styles.dayCell, !day.current && styles.mutedDayCell, active && styles.activeDayCell]}><Text style={[styles.dayNumber, !day.current && styles.mutedDayNumber, active && styles.activeDayNumber]}>{day.day}</Text>{count > 0 && <View style={[styles.eventDot, active && styles.activeEventDot]} />}</Pressable>; })}</View></View>
      <View style={styles.sectionHeader}><View><Text style={styles.sectionTitle}>مناسبات {selectedDate}</Text><Text style={styles.sectionHint}>{selectedBookings.length} حجوزات في هذا اليوم</Text></View></View>
      {selectedBookings.map((item) => <View key={item.id} style={styles.calendarEvent}><View style={styles.eventAccent} /><View style={styles.eventContent}><View style={styles.eventTitleRow}><Text style={styles.eventTitle}>{item.eventName}</Text><Text style={styles.eventStatus}>{item.status}</Text></View><Text style={styles.eventMeta}>{item.time} · {item.location}</Text><Text style={styles.eventClient}>{item.client} · {money(item.total)}</Text></View></View>)}
      {selectedBookings.length === 0 && <View style={styles.emptyState}><MaterialIcons name="event-note" size={34} color="#A6A0B4" /><Text style={styles.emptyTitle}>اليوم متاح</Text><Text style={styles.emptySubtitle}>يمكنك إضافة مناسبة جديدة لهذا التاريخ</Text><Pressable onPress={() => { setForm({ ...emptyForm, date: selectedDate }); setShowForm(true); }} style={styles.smallPrimary}><Text style={styles.smallPrimaryText}>إضافة حجز</Text></Pressable></View>}
    </ScrollView>;
  };

  const renderFinance = () => {
    const income = bookings.reduce((sum, booking) => sum + booking.paid, 0);
    const billed = bookings.reduce((sum, booking) => sum + booking.total, 0);
    return <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}><View style={styles.pageHeader}><View><Text style={styles.pageEyebrow}>متابعة مالية</Text><Text style={styles.pageTitle}>الحسابات</Text></View><View style={styles.financeIcon}><MaterialIcons name="insights" size={22} color="#8B5CF6" /></View></View><View style={styles.balanceCard}><Text style={styles.balanceLabel}>إجمالي المحصل</Text><Text style={styles.balanceValue}>{money(income)}</Text><View style={styles.balanceFooter}><Text style={styles.balanceHint}>من إجمالي {money(billed)}</Text><Text style={styles.balancePercent}>{billed ? Math.round((income / billed) * 100) : 0}%</Text></View><View style={styles.balanceTrack}><View style={[styles.balanceFill, { width: `${billed ? Math.min((income / billed) * 100, 100) : 0}%` }]} /></View></View><View style={styles.financeTiles}><View style={styles.financeTile}><Text style={styles.financeTileLabel}>المتبقي للتحصيل</Text><Text style={styles.financeTileValue}>{money(totalDue)}</Text><Text style={styles.financeTileCaption}>من كل الحجوزات</Text></View><View style={styles.financeTile}><Text style={styles.financeTileLabel}>متوسط الحجز</Text><Text style={styles.financeTileValue}>{money(bookings.length ? Math.round(billed / bookings.length) : 0)}</Text><Text style={styles.financeTileCaption}>للمناسبة الواحدة</Text></View></View><View style={styles.sectionHeader}><Text style={styles.sectionTitle}>ملخص الحجوزات</Text></View>{bookings.map((item) => <View key={item.id} style={styles.financeRow}><View style={styles.financeRowIcon}><MaterialIcons name={item.paid >= item.total ? "check" : "schedule"} size={18} color={item.paid >= item.total ? "#178F5B" : "#D89B21"} /></View><View style={styles.financeRowInfo}><Text style={styles.financeRowTitle}>{item.eventName}</Text><Text style={styles.financeRowMeta}>{item.client} · {item.date}</Text></View><View><Text style={styles.financeRowValue}>{money(item.paid)}</Text><Text style={styles.financeRowDue}>متبقي {money(remainingAmount(item.total, item.paid))}</Text></View></View>)}</ScrollView>;
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]}>
      <View style={styles.appShell}>
        {section === "home" && renderHome()}
        {section === "bookings" && renderBookings()}
        {section === "calendar" && renderCalendar()}
        {section === "finance" && renderFinance()}
        <View style={styles.bottomNav}>{([{ key: "home", label: "الرئيسية", icon: "home" }, { key: "bookings", label: "الحجوزات", icon: "event-note" }, { key: "calendar", label: "التقويم", icon: "calendar-month" }, { key: "finance", label: "الحسابات", icon: "account-balance-wallet" }] as const).map((item) => <Pressable key={item.key} onPress={() => setSection(item.key)} style={({ pressed }) => [styles.navItem, pressed && styles.pressed]}><View style={[styles.navIconWrap, section === item.key && styles.activeNavIcon]}><MaterialIcons name={item.icon as keyof typeof MaterialIcons.glyphMap} size={21} color={section === item.key ? "#FFFFFF" : "#A6A0B4"} /></View><Text style={[styles.navLabel, section === item.key && styles.activeNavLabel]}>{item.label}</Text></Pressable>)}</View>
      </View>
      <Modal visible={showForm} animationType="slide" transparent onRequestClose={() => setShowForm(false)}><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.modalOverlay}><View style={styles.modalCard}><View style={styles.modalHeader}><Pressable onPress={() => setShowForm(false)} style={styles.closeButton}><MaterialIcons name="close" size={22} color="#6E667F" /></Pressable><View style={styles.modalTitleWrap}><Text style={styles.modalTitle}>إضافة حجز جديد</Text><Text style={styles.modalSubtitle}>سجّل تفاصيل المناسبة القادمة</Text></View><View style={styles.modalHeaderIcon}><MaterialIcons name="event-available" size={23} color="#FFFFFF" /></View></View><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.formContent}><Text style={styles.inputLabel}>اسم المناسبة *</Text><TextInput value={form.eventName} onChangeText={(value) => setForm({ ...form, eventName: value })} placeholder="مثال: زفاف عائلة العبدالله" placeholderTextColor="#B4ADBF" style={styles.input} textAlign="right" /><Text style={styles.inputLabel}>اسم العميل *</Text><TextInput value={form.client} onChangeText={(value) => setForm({ ...form, client: value })} placeholder="الاسم الكامل" placeholderTextColor="#B4ADBF" style={styles.input} textAlign="right" /><Text style={styles.inputLabel}>جوال العميل لتأكيد SMS</Text><TextInput value={form.phone} onChangeText={(value) => setForm({ ...form, phone: value })} placeholder="+9665XXXXXXXX" placeholderTextColor="#B4ADBF" style={styles.input} keyboardType="phone-pad" textAlign="right" autoCapitalize="none" /><View style={styles.formRow}><View style={styles.halfInput}><Text style={styles.inputLabel}>التاريخ *</Text><TextInput value={form.date} onChangeText={(value) => setForm({ ...form, date: value })} placeholder="YYYY-MM-DD" placeholderTextColor="#B4ADBF" style={styles.input} textAlign="right" autoCapitalize="none" /></View><View style={styles.halfInput}><Text style={styles.inputLabel}>الوقت</Text><TextInput value={form.time} onChangeText={(value) => setForm({ ...form, time: value })} placeholder="08:00 م" placeholderTextColor="#B4ADBF" style={styles.input} textAlign="right" /></View></View><Text style={styles.inputLabel}>المكان</Text><TextInput value={form.location} onChangeText={(value) => setForm({ ...form, location: value })} placeholder="اسم القاعة أو الموقع" placeholderTextColor="#B4ADBF" style={styles.input} textAlign="right" /><View style={styles.formRow}><View style={styles.halfInput}><Text style={styles.inputLabel}>الإجمالي (ر.س) *</Text><TextInput value={form.total} onChangeText={(value) => setForm({ ...form, total: value })} placeholder="0" placeholderTextColor="#B4ADBF" style={styles.input} keyboardType="numeric" textAlign="right" /></View><View style={styles.halfInput}><Text style={styles.inputLabel}>المدفوع (ر.س)</Text><TextInput value={form.paid} onChangeText={(value) => setForm({ ...form, paid: value })} placeholder="0" placeholderTextColor="#B4ADBF" style={styles.input} keyboardType="numeric" textAlign="right" /></View></View><Text style={styles.inputLabel}>عدد الضيوف</Text><TextInput value={form.guests} onChangeText={(value) => setForm({ ...form, guests: value })} placeholder="مثال: 300" placeholderTextColor="#B4ADBF" style={styles.input} keyboardType="numeric" textAlign="right" /><Text style={styles.inputLabel}>ملاحظات</Text><TextInput value={form.notes} onChangeText={(value) => setForm({ ...form, notes: value })} placeholder="أي تفاصيل إضافية للفرقة" placeholderTextColor="#B4ADBF" style={[styles.input, styles.notesInput]} multiline textAlign="right" /><Pressable onPress={saveBooking} style={({ pressed }) => [styles.saveButton, pressed && styles.pressed]}><MaterialIcons name="check" size={21} color="#FFFFFF" /><Text style={styles.saveButtonText}>حفظ الحجز</Text></Pressable></ScrollView></View></KeyboardAvoidingView></Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  appShell: { flex: 1, backgroundColor: "#FBF8F4" },
  flexOne: { flex: 1 },
  scrollContent: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 112 },
  heroRow: { flexDirection: "row-reverse", alignItems: "center", marginBottom: 18, gap: 11 },
  avatar: { width: 47, height: 47, borderRadius: 16, backgroundColor: "#231942", alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#FFFFFF", fontSize: 21, fontWeight: "800" },
  heroText: { flex: 1, alignItems: "flex-end" },
  greeting: { color: "#231942", fontSize: 18, fontWeight: "800" },
  heroSubtitle: { color: "#8C839B", fontSize: 12, marginTop: 3 },
  iconButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#EFEAF4" },
  brandBanner: { backgroundColor: "#231942", borderRadius: 24, padding: 18, flexDirection: "row-reverse", alignItems: "center", overflow: "hidden" },
  brandIcon: { width: 52, height: 52, borderRadius: 18, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center" },
  brandCopy: { flex: 1, alignItems: "flex-end", marginRight: 12 },
  brandTitle: { color: "#FFFFFF", fontSize: 17, fontWeight: "800" },
  brandCaption: { color: "#C7BDD8", fontSize: 11, marginTop: 4 },
  liveDot: { flexDirection: "row-reverse", alignItems: "center", gap: 5, backgroundColor: "rgba(255,255,255,0.12)", paddingHorizontal: 8, paddingVertical: 5, borderRadius: 10 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#6EE7B7" },
  liveText: { color: "#D9FBEA", fontSize: 10, fontWeight: "700" },
  sectionHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginTop: 25, marginBottom: 12 },
  sectionTitle: { color: "#231942", fontSize: 16, fontWeight: "800", textAlign: "right" },
  sectionHint: { color: "#A6A0B4", fontSize: 11 },
  linkText: { color: "#8B5CF6", fontSize: 12, fontWeight: "700" },
  statsGrid: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 10 },
  statCard: { width: "48.4%", minHeight: 112, borderRadius: 18, padding: 14, borderWidth: 1 },
  statCardPurple: { backgroundColor: "#F1ECFF", borderColor: "#E2D8FF" },
  statCardGreen: { backgroundColor: "#E9F8F1", borderColor: "#D2F0E1" },
  statCardAmber: { backgroundColor: "#FFF6DF", borderColor: "#F9EAC3" },
  statCardRose: { backgroundColor: "#FFF0F0", borderColor: "#F6DADA" },
  statIcon: { width: 32, height: 32, borderRadius: 11, backgroundColor: "rgba(255,255,255,0.72)", alignItems: "center", justifyContent: "center", marginBottom: 7 },
  statNumber: { color: "#231942", fontSize: 23, fontWeight: "900", textAlign: "right" },
  statLabel: { color: "#776B8A", fontSize: 11, marginTop: 2, textAlign: "right" },
  quickActions: { flexDirection: "row-reverse", gap: 10 },
  primaryAction: { flex: 1, height: 51, borderRadius: 16, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 7, shadowColor: "#8B5CF6", shadowOpacity: 0.22, shadowRadius: 10, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
  primaryActionText: { color: "#FFFFFF", fontWeight: "800", fontSize: 13 },
  secondaryAction: { flex: 1, height: 51, borderRadius: 16, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E6DFF2", alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 7 },
  secondaryActionText: { color: "#5E477F", fontWeight: "800", fontSize: 13 },
  upcomingCard: { backgroundColor: "#FFFFFF", borderRadius: 18, borderWidth: 1, borderColor: "#EEE9F3", padding: 13, flexDirection: "row-reverse", alignItems: "center", marginBottom: 9 },
  upcomingDate: { width: 45, height: 50, borderRadius: 14, backgroundColor: "#F1ECFF", alignItems: "center", justifyContent: "center" },
  upcomingDay: { color: "#6D45D5", fontSize: 18, fontWeight: "900" },
  upcomingMonth: { color: "#8B5CF6", fontSize: 10, fontWeight: "700" },
  upcomingInfo: { flex: 1, alignItems: "flex-end", marginHorizontal: 12 },
  upcomingTitle: { color: "#2A2140", fontSize: 13, fontWeight: "800" },
  upcomingMeta: { color: "#90879D", fontSize: 11, marginTop: 5 },
  emptyState: { alignItems: "center", justifyContent: "center", backgroundColor: "#FFFFFF", borderRadius: 20, padding: 30, marginTop: 8, borderWidth: 1, borderColor: "#EEE9F3" },
  emptyTitle: { color: "#514763", fontSize: 14, fontWeight: "800", marginTop: 10 },
  emptySubtitle: { color: "#A6A0B4", fontSize: 12, marginTop: 5, textAlign: "center" },
  pageHeader: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 15, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  pageEyebrow: { color: "#8B5CF6", fontSize: 11, fontWeight: "800", textAlign: "right", marginBottom: 3 },
  pageTitle: { color: "#231942", fontSize: 25, fontWeight: "900", textAlign: "right" },
  roundPrimary: { width: 46, height: 46, borderRadius: 16, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center", shadowColor: "#8B5CF6", shadowOpacity: 0.24, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  searchBox: { marginHorizontal: 20, height: 48, borderRadius: 15, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#ECE7F1", flexDirection: "row-reverse", alignItems: "center", paddingHorizontal: 14, gap: 8 },
  searchInput: { flex: 1, color: "#231942", fontSize: 12, textAlign: "right" },
  filterRow: { paddingHorizontal: 20, paddingVertical: 14, gap: 8, flexDirection: "row-reverse" },
  filterChip: { borderRadius: 12, paddingHorizontal: 15, paddingVertical: 8, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#ECE7F1" },
  activeFilterChip: { backgroundColor: "#231942", borderColor: "#231942" },
  filterText: { color: "#8B8395", fontSize: 11, fontWeight: "700" },
  activeFilterText: { color: "#FFFFFF" },
  listContent: { paddingHorizontal: 20, paddingBottom: 112, gap: 10 },
  bookingCard: { backgroundColor: "#FFFFFF", borderRadius: 20, borderWidth: 1, borderColor: "#EEE9F3", padding: 15 },
  bookingTopRow: { flexDirection: "row-reverse", alignItems: "center" },
  bookingTitleWrap: { flex: 1, alignItems: "flex-end", marginHorizontal: 10 },
  bookingTitle: { color: "#2A2140", fontSize: 14, fontWeight: "800" },
  bookingClient: { color: "#9A91A7", fontSize: 11, marginTop: 4 },
  dateBox: { width: 48, height: 51, borderRadius: 14, backgroundColor: "#F6F2FF", justifyContent: "center", alignItems: "center" },
  dateBoxDay: { color: "#6D45D5", fontSize: 18, fontWeight: "900" },
  dateBoxMonth: { color: "#8B5CF6", fontSize: 9, fontWeight: "700" },
  typeBadge: { borderRadius: 9, paddingHorizontal: 8, paddingVertical: 5 },
  purpleBadge: { backgroundColor: "#F1ECFF" },
  greenBadge: { backgroundColor: "#E9F8F1" },
  amberBadge: { backgroundColor: "#FFF6DF" },
  typeBadgeText: { color: "#6D45D5", fontSize: 10, fontWeight: "800" },
  bookingMetaRow: { flexDirection: "row-reverse", gap: 12, marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: "#F1EEF4" },
  metaItem: { flexDirection: "row-reverse", alignItems: "center", gap: 4, flex: 1 },
  metaText: { color: "#80768F", fontSize: 10, textAlign: "right", flexShrink: 1 },
  paymentRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8, marginTop: 14 },
  paymentLabel: { color: "#A6A0B4", fontSize: 9, textAlign: "right" },
  paymentValue: { color: "#2A2140", fontSize: 11, fontWeight: "800", marginTop: 2 },
  progressTrack: { height: 6, backgroundColor: "#EEEAF4", borderRadius: 3, flex: 1, overflow: "hidden" },
  progressFill: { height: "100%", backgroundColor: "#8B5CF6", borderRadius: 3 },
  paymentPercent: { color: "#8B5CF6", fontSize: 10, fontWeight: "800" },
  cardActions: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginTop: 12 },
  cardActionGroup: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  smsButton: { flexDirection: "row-reverse", gap: 3, alignItems: "center", padding: 4 },
  smsText: { color: "#178F5B", fontSize: 10, fontWeight: "800" },
  disabledButton: { opacity: 0.55 },
  totalText: { color: "#70657F", fontSize: 10 },
  deleteButton: { flexDirection: "row-reverse", gap: 3, alignItems: "center", padding: 4 },
  deleteText: { color: "#C94C4C", fontSize: 10, fontWeight: "700" },
  calendarCard: { backgroundColor: "#FFFFFF", borderRadius: 22, borderWidth: 1, borderColor: "#EEE9F3", padding: 15 },
  monthHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 15 },
  monthTitle: { color: "#2A2140", fontSize: 15, fontWeight: "900" },
  monthArrow: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#F7F4FA", alignItems: "center", justifyContent: "center" },
  weekRow: { flexDirection: "row-reverse", justifyContent: "space-around", marginBottom: 7 },
  weekLabel: { width: "14.2%", color: "#A6A0B4", fontSize: 10, textAlign: "center", fontWeight: "700" },
  calendarGrid: { flexDirection: "row-reverse", flexWrap: "wrap" },
  dayCell: { width: "14.28%", height: 43, alignItems: "center", justifyContent: "center", borderRadius: 13, marginVertical: 1 },
  mutedDayCell: { opacity: 0.45 },
  activeDayCell: { backgroundColor: "#8B5CF6" },
  dayNumber: { color: "#4C425D", fontSize: 12, fontWeight: "700" },
  mutedDayNumber: { color: "#A6A0B4" },
  activeDayNumber: { color: "#FFFFFF", fontWeight: "900" },
  eventDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: "#8B5CF6", marginTop: 3 },
  activeEventDot: { backgroundColor: "#FFFFFF" },
  todayButton: { backgroundColor: "#F1ECFF", borderRadius: 11, paddingHorizontal: 13, paddingVertical: 8 },
  todayButtonText: { color: "#6D45D5", fontSize: 11, fontWeight: "800" },
  calendarEvent: { backgroundColor: "#FFFFFF", borderRadius: 18, padding: 14, marginBottom: 9, flexDirection: "row-reverse", borderWidth: 1, borderColor: "#EEE9F3" },
  eventAccent: { width: 4, borderRadius: 2, backgroundColor: "#8B5CF6", marginLeft: 11 },
  eventContent: { flex: 1, alignItems: "flex-end" },
  eventTitleRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  eventTitle: { color: "#2A2140", fontSize: 13, fontWeight: "800" },
  eventStatus: { color: "#6D45D5", backgroundColor: "#F1ECFF", borderRadius: 7, paddingHorizontal: 6, paddingVertical: 3, fontSize: 9, fontWeight: "800" },
  eventMeta: { color: "#81778F", fontSize: 11, marginTop: 6 },
  eventClient: { color: "#A6A0B4", fontSize: 10, marginTop: 5 },
  smallPrimary: { backgroundColor: "#8B5CF6", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 9, marginTop: 15 },
  smallPrimaryText: { color: "#FFFFFF", fontSize: 11, fontWeight: "800" },
  financeIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: "#F1ECFF", alignItems: "center", justifyContent: "center" },
  balanceCard: { marginHorizontal: 20, backgroundColor: "#231942", borderRadius: 23, padding: 20 },
  balanceLabel: { color: "#C7BDD8", fontSize: 12, textAlign: "right" },
  balanceValue: { color: "#FFFFFF", fontSize: 29, fontWeight: "900", textAlign: "right", marginTop: 8 },
  balanceFooter: { flexDirection: "row-reverse", justifyContent: "space-between", marginTop: 18 },
  balanceHint: { color: "#AFA4C1", fontSize: 10 },
  balancePercent: { color: "#A78BFA", fontSize: 12, fontWeight: "900" },
  balanceTrack: { height: 7, backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 4, marginTop: 9, overflow: "hidden" },
  balanceFill: { height: "100%", backgroundColor: "#A78BFA", borderRadius: 4 },
  financeTiles: { flexDirection: "row-reverse", gap: 10, paddingHorizontal: 20, marginTop: 12 },
  financeTile: { flex: 1, backgroundColor: "#FFFFFF", borderRadius: 18, padding: 14, borderWidth: 1, borderColor: "#EEE9F3" },
  financeTileLabel: { color: "#82788E", fontSize: 10, textAlign: "right" },
  financeTileValue: { color: "#2A2140", fontSize: 16, fontWeight: "900", textAlign: "right", marginTop: 9 },
  financeTileCaption: { color: "#B0A8B8", fontSize: 9, textAlign: "right", marginTop: 4 },
  financeRow: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#EEE9F3", borderRadius: 16, padding: 13, marginBottom: 9, flexDirection: "row-reverse", alignItems: "center" },
  financeRowIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#F7F4FA", alignItems: "center", justifyContent: "center" },
  financeRowInfo: { flex: 1, alignItems: "flex-end", marginHorizontal: 10 },
  financeRowTitle: { color: "#2A2140", fontSize: 12, fontWeight: "800" },
  financeRowMeta: { color: "#9A91A7", fontSize: 10, marginTop: 4 },
  financeRowValue: { color: "#2A2140", fontSize: 11, fontWeight: "800", textAlign: "right" },
  financeRowDue: { color: "#C94C4C", fontSize: 9, marginTop: 4, textAlign: "right" },
  bottomNav: { position: "absolute", left: 12, right: 12, bottom: 10, height: 70, borderRadius: 23, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#EEE9F3", flexDirection: "row-reverse", justifyContent: "space-around", alignItems: "center", shadowColor: "#231942", shadowOpacity: 0.08, shadowRadius: 13, shadowOffset: { width: 0, height: 5 }, elevation: 5 },
  navItem: { alignItems: "center", justifyContent: "center", minWidth: 64, gap: 3 },
  navIconWrap: { width: 33, height: 30, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  activeNavIcon: { backgroundColor: "#8B5CF6" },
  navLabel: { color: "#A6A0B4", fontSize: 9, fontWeight: "700" },
  activeNavLabel: { color: "#6D45D5" },
  pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  modalOverlay: { flex: 1, backgroundColor: "rgba(35,25,66,0.48)", justifyContent: "flex-end" },
  modalCard: { maxHeight: "92%", backgroundColor: "#FBF8F4", borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingTop: 12 },
  modalHeader: { paddingHorizontal: 20, paddingVertical: 12, flexDirection: "row-reverse", alignItems: "center", borderBottomWidth: 1, borderBottomColor: "#EEE9F3" },
  closeButton: { width: 38, height: 38, borderRadius: 12, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
  modalTitleWrap: { flex: 1, alignItems: "flex-end", marginHorizontal: 10 },
  modalTitle: { color: "#231942", fontSize: 18, fontWeight: "900" },
  modalSubtitle: { color: "#9A91A7", fontSize: 11, marginTop: 3 },
  modalHeaderIcon: { width: 43, height: 43, borderRadius: 14, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center" },
  formContent: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 35 },
  inputLabel: { color: "#5F566D", fontSize: 11, fontWeight: "800", textAlign: "right", marginBottom: 7, marginTop: 12 },
  input: { height: 48, borderRadius: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E9E3EF", paddingHorizontal: 13, color: "#231942", fontSize: 12 },
  formRow: { flexDirection: "row-reverse", gap: 10 },
  halfInput: { flex: 1 },
  notesInput: { height: 84, paddingTop: 13, textAlignVertical: "top" },
  saveButton: { height: 52, borderRadius: 16, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 8, marginTop: 22 },
  saveButtonText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900" },
});
