export type BookingStatus = "مؤكد" | "معلّق" | "مكتمل";

export function remainingAmount(total: number, paid: number): number {
  return Math.max(total - paid, 0);
}

export function statusForPayment(total: number, paid: number): BookingStatus {
  return paid >= total && total > 0 ? "مؤكد" : "معلّق";
}

export function paymentPercent(total: number, paid: number): number {
  if (total <= 0) return 0;
  return Math.round(Math.min(Math.max(paid / total, 0), 1) * 100);
}

export function monthKey(year: number, month: number): string {
  return `${year}-${String(month).padStart(2, "0")}`;
}
